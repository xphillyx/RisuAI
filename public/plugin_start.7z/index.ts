//@name new_plugin
//@display-name New Plugin
//@api 3.0
//@arg example_arg string

// Before you start, please change the name,
// display name, and other metadata above to reflect your plugin's purpose.

// If you want strict type checking, please enable "strict": true in your tsconfig.json.

(async () => {
    console.log("Hello from New Plugin!");

})();